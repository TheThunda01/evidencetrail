# EvidenceTrail audit summary

EvidenceTrail version: `0.3.0`

Source file: demo\_records\.csv

Source SHA-256: `c761ae8310e6bc0944c2eba1fab987d7e79ddb599942b8e8207ab25120218025`

- Extraction records: 20
- Distinct nonempty report IDs: 5
- Rules checked: 9
- Findings: 5
- Records with findings: 6
- Errors: 2
- Items for review: 3

## Findings by rule

| Rule | Findings |
| --- | ---: |
| `MISSING_RECORD_ID` | 0 |
| `DUPLICATE_RECORD_ID` | 1 |
| `MISSING_REPORT_ID` | 0 |
| `MISSING_FIELD` | 0 |
| `INVALID_EVIDENCE_STATUS` | 1 |
| `INVALID_REVIEW_STATUS` | 0 |
| `MISSING_REPORTED_VALUE` | 1 |
| `MISSING_SOURCE_LOCATOR` | 1 |
| `REVIEWER_DISAGREEMENT` | 1 |

## Review progress as recorded

| Status | Records |
| --- | ---: |
| Pending | 19 |
| Verified | 0 |
| Disagreement | 1 |
| Invalid | 0 |

These are user-entered statuses. EvidenceTrail has not independently verified the sources.

A duplicate record-ID group counts as one finding, even when it affects several rows. Report IDs identify source reports; their count is not a count of distinct studies, programmes, or surveillance systems.

## Interpretation

This audit checks table structure and review metadata. It does not read source articles, verify extracted claims, resolve reviewer disagreements, or establish scientific validity. A clean result means these rules found no issues; it does not certify the extraction.

An error identifies a required identifier, extraction field, or controlled status that needs correction. An item for review identifies missing supporting metadata or a recorded reviewer disagreement. Pending review alone is not flagged. A Verified status is recorded metadata, not verification performed by EvidenceTrail.

Not reported, Unclear, Explicitly absent, and Not applicable remain separate statuses. EvidenceTrail does not infer absence from missing information.

Spreadsheet row numbers use row 1 for the header and row 2 for the first data record. Use the findings CSV to locate individual records. This summary omits extracted values and record identifiers.
